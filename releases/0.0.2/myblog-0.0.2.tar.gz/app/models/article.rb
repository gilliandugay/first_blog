class Article < ActiveRecord::Base
  belongs_to :author
  has_many :comments

  validates_presence_of :title, :message => "Title required."
  validates_presence_of :body, :message => "Body text required."
end
