class Comment < ActiveRecord::Base
  belongs_to :article
  validates_presence_of :email, :message => "Email address required."
  validates_presence_of :body, :message => "Body text required."
end
